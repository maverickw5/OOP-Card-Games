#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
using namespace std;

class CardSource {
    private:
        string cardSuit[4] = {"H", "S", "D", "C"};
        string cardNum[13] = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K"};
    public:
        vector<string> pileCard, tableCard;
        vector<string> playerCard, compCard;
        vector<string> playerHand, compHand;
        vector<string> playerStack, compStack;
        vector<string> tmpPlayer, tmpComp; 
        int playerPoint, compPoint;
        void generate() {
            int nCard = 0;
            string card;
            vector<string> Deck;
            for(int i=0; i<4; i++) {
                for(int j=0; j<13; j++) {
                    card = cardNum[j] + cardSuit[i];
                    Deck.push_back(card);
                    nCard++;
                }
            }
            while(nCard > 0) {
                int randCard = rand() % nCard;
                string drawCard = Deck.at(randCard);
                Deck.erase(Deck.begin() + randCard);
                pileCard.push_back(drawCard);
                nCard--;
            }
        }
        void dealt() {
            int x = 0;
            while(x < 24) {
                playerCard.push_back(pileCard.at(x));
                pileCard.erase(pileCard.begin() + x);
                x++;
                compCard.push_back(pileCard.at(x));
                pileCard.erase(pileCard.begin() + x);
                x++;
            }
            for(int i=0; i<playerCard.size(); i++) {
                cout << playerCard.at(i) << "  ";
            }
            cout << endl << "Note: H = Hearts, S = Spades, D = Diamonds, C = Clubs, T = 10" << endl;
            tableCard.clear();
            for(int i=0; i<4; i++) {
                tableCard.insert(tableCard.begin() + i, " ");
            }
            draw();
            playerPoint = compPoint = 0;
            tmpPlayer.clear();
            tmpComp.clear();
            playerStack.clear();
            compStack.clear();
        }
        void draw() {
            for(int i=0; i<4; i++) {
                string tmp = tableCard.at(i);
                if(tmp == " ") {
                    tableCard.erase(tableCard.begin() + i);
                    int randCard = rand() % pileCard.size();
                    string tmp1 = pileCard.at(randCard);
                    pileCard.erase(pileCard.begin() + randCard);
                    tableCard.insert(tableCard.begin() + i, tmp1);
                }
            }
        }
        int tcN[24] = {};
        void move() {
            playerHand.clear();
            int cardvalue, k = 0;
            string target, capture;
            for(int x=0; x<tableCard.size(); x++) {
                cardvalue = 0;
                string tc = tableCard.at(x);
                target = tc[0];
                for(int i=0; i<13; i++) {
                    string tmp = cardNum[i];
                    if(target == tmp) {
                        cardvalue = i + 1;
                        break;
                    }
                }
                if(cardvalue > 0 && cardvalue < 10) {
                    int capturevalue = 9 - cardvalue;
                    for(int i=0; i<playerCard.size(); i++) {
                        string tmp = playerCard.at(i);
                        capture = tmp[0];
                        if(capture == cardNum[capturevalue])
                            playerHand.push_back(tmp);
                    }
                }
                else if(cardvalue >= 10) {
                    int capturevalue = cardvalue - 1;
                    for(int i=0; i<playerCard.size(); i++) {
                        string tmp = playerCard.at(i);
                        capture = tmp[0];
                        if(capture == cardNum[capturevalue])
                            playerHand.push_back(tmp);
                    }
                }
                while(k != playerHand.size()) {
                    cout << k << ". Use " << playerHand.at(k) << " to capture " << tc << endl;
                    tcN[k] = x;
                    k++;
                }
            }
            if(playerHand.size() != 0)     
                cout << endl;
        }
        void player(int input) {
            int in = input;
            string tmpcard;
            string tmp1 = playerHand.at(in);
            for(int i=0; i<playerCard.size(); i++) {
                int n = i;
                if(playerCard.at(n) == tmp1) {
                    playerCard.erase(playerCard.begin() + n);
                    break;
                }
            }
            tmpcard = tmp1[0];
            playerStack.push_back(tmpcard);
            string tmp2 = tableCard.at(tcN[in]);
            tableCard.erase(tableCard.begin() + tcN[in]);
            tmpcard = tmp2[0];
            playerStack.push_back(tmpcard);
            tableCard.insert(tableCard.begin() + tcN[in], " ");
            tmpPlayer.push_back(tmp1 + " " + tmp2);
            if(tmp1 == "AS" || tmp2 == "AS")
                playerPoint -= 10;
        }
        void computer() {
            compHand.clear();
            int cardvalue, k = 0;
            string target, capture;
            for(int x=0; x<tableCard.size(); x++) {
                cardvalue = 0;
                string tc = tableCard.at(x);
                target = tc[0];
                for(int i=0; i<13; i++) {
                    string tmp = cardNum[i];
                    if(target == tmp) {
                        cardvalue = i + 1;
                        break;
                    }
                }
                if(cardvalue > 0 && cardvalue < 10) {
                    int capturevalue = 9 - cardvalue;
                    for(int i=0; i<compCard.size(); i++) {
                        string tmp = compCard.at(i);
                        capture = tmp[0];
                        if(capture == cardNum[capturevalue])
                            compHand.push_back(tmp);
                    }
                }
                else if(cardvalue >= 10) {
                    int capturevalue = cardvalue - 1;
                    for(int i=0; i<compCard.size(); i++) {
                        string tmp = compCard.at(i);
                        capture = tmp[0];
                        if(capture == cardNum[capturevalue])
                            compHand.push_back(tmp);
                    }
                }
                while(k != compHand.size()) {
                    tcN[k] = x;
                    k++;
                }
            }
            if(compHand.size() == 0) {
                int randCard = rand() % compCard.size();
                string nocard = compCard.at(randCard);
                tableCard.push_back(nocard);
                compCard.erase(compCard.begin() + randCard);
                cout << "Computer has no possible move to play" << endl;
                cout << "Computer placed " << nocard << " to the table" << endl;
            }
            else {
                int n;
                string compmove, tmpcard;
                for(int i=12; i>0; i--) {
                    string highcard = cardNum[i];
                    for(int j=0; j<compHand.size(); j++) {
                        n = j;
                        string tmp = compHand.at(n);
                        tmpcard = tmp[0];
                        if(tmpcard == "A") {
                            compmove = tmp;
                            break;
                        }
                        else if(tmpcard == highcard) {
                            compmove = tmp;
                            break;
                        }
                    }
                    if(compmove.size() != 0)
                        break;
                }
                for(int i=0; i<compCard.size(); i++) {
                    int tmp = i;
                    if(compmove == compCard.at(tmp)) {
                        compCard.erase(compCard.begin() + tmp);
                        break;
                    }
                }
                tmpcard = compmove[0];
                compStack.push_back(tmpcard);
                string tmptable = tableCard.at(tcN[n]);
                tableCard.erase(tableCard.begin() + tcN[n]);
                tmpcard = tmptable[0];
                compStack.push_back(tmpcard);
                tableCard.insert(tableCard.begin() + tcN[n], " ");
                tmpComp.push_back(compmove + " " + tmptable);
                cout << "Computer used " << compmove << " to capture " << tmptable << endl;
                if(compmove == "AS" || tmptable == "AS")
                    compPoint -= 10;
            }
        }
        void game() {
            int cardvalue;
            for(int x=0; x<playerStack.size(); x++) {
                string tmpcard = playerStack.at(x);
                for(int i=0; i<13; i++) {
                    string tmp = cardNum[i];
                    if(tmpcard == tmp) {
                        cardvalue = i + 1;
                        break;
                    }
                }
                if(cardvalue > 1 && cardvalue < 9) {
                    playerPoint += cardvalue;
                }
                else {
                    if(cardvalue == 1)
                        playerPoint += 20;
                    else
                        playerPoint += 10;
                }
            }
            for(int x=0; x<compStack.size(); x++) {
                string tmpcard = compStack.at(x);
                for(int i=0; i<13; i++) {
                    string tmp = cardNum[i];
                    if(tmpcard == tmp) {
                        cardvalue = i + 1;
                        break;
                    }
                }
                if(cardvalue > 1 && cardvalue < 9) {
                    compPoint += cardvalue;
                }
                else {
                    if(cardvalue == 1)
                        compPoint += 20;
                    else
                        compPoint += 10;
                }
            }
            if(playerPoint == compPoint)
                cout << "A tie!" << endl << endl;
            else if(playerPoint > compPoint)
                cout << "You win!" << endl << endl;
            else
                cout << "You lost!" << endl << endl;
            cout << "You have " << playerStack.size() << " card(s)" << endl;
            for(int i=0; i<tmpPlayer.size(); i++)
                cout << tmpPlayer.at(i) << " ";
            cout << endl << "Your point is " << playerPoint << endl << endl;
            cout << "Computer have " << compStack.size() << " card(s)" << endl;
            for(int i=0; i<tmpComp.size(); i++)
                cout << tmpComp.at(i) << " ";
            cout << endl << "Computer's point is " << compPoint << endl << endl;
        }
        void nomove(int input) {
            int in = input;
            string tmp = playerCard.at(in);
            tableCard.push_back(tmp);
            playerCard.erase(playerCard.begin() + in);
        }
        void resize() {
            if(tableCard.size() > 4) {
                for(int i=0; i<tableCard.size(); i++) {
                    int n = i;
                    if(tableCard.at(n) == " ") {
                        tableCard.erase(tableCard.begin() + n);
                        break;
                    }
                }
            }
        }
};
class ChineseTenTable: public CardSource {
    public:
        void print() {
            printCard();
            cout << endl;
        }
        void printCard() {
            printcardHeader();
            printcardNumber(0);     
            printcardSuit();
            printcardNumber(1);
            printcardHeader();
            cout << endl;
        }
        void printcardHeader() {
            cout << endl;
            for(int x=0; x<tableCard.size(); x++) {
                for(int i=0; i<12; i++) {
                    cout << "[]";
                }
                cout << "  ";
            }
        }
        void printcardNumber(int topBottom) {
            int tb = topBottom;
            for(int y=0; y<3; y++) {
                cout << endl;
                for(int x=0; x<tableCard.size(); x++) {
                    for(int i=0; i<12; i++) {
                        if(i == 0 || i == 11)
                            cout << "[]";
                        else if(tb == 0 && y == 1 && i == 2) {
                            string tmp = tableCard.at(x);
                            cout << tmp[0] << " ";
                        }
                        else if(tb == 1 && y == 1 && i == 9) {
                            string tmp = tableCard.at(x);
                            cout << " " << tmp[0];
                        }
                        else
                            cout << "  ";
                    }
                    cout << "  ";
                }
            }
        }
        void printcardSuit() {
            for(int y=0; y<5; y++) {
                cout << endl;
                int l = y;
                for(int x=0; x<tableCard.size(); x++) {
                    cout << "[]";
                    string tmp = tableCard.at(x);
                    if(tmp == " ")
                        printBlank();
                    if(tmp[1] == 'H')
                        printHearts(l);
                    else if(tmp[1] == 'S')
                        printSpades(l);
                    else if(tmp[1] == 'D')
                        printDiamonds(l);
                    else if(tmp[1] == 'C')
                        printClubs(l);
                    cout << "[]  ";
                }
            }
        }
        void printBlank() {
            cout << "                    ";
        }
        void printHearts(int line) {
            int L = line;
            switch(L) {
                case 0:
                    cout << "     * *   * *      ";
                    break;
                case 1:
                    cout << "   * * * * * * *    ";
                    break;
                case 2:
                    cout << "     * * * * *      ";
                    break;
                case 3:
                    cout << "       * * *        ";
                    break;
                case 4:
                    cout << "         *          ";
                    break;
            }
        }
        void printSpades(int line) {
            int L = line;
            switch(L) {
                case 0:
                    cout << "         *          ";
                    break;
                case 1:
                    cout << "       * * *        ";
                    break;
                case 2:
                    cout << "     * * * * *      ";
                    break;
                case 3:
                    cout << "     * * * * *      ";
                    break;
                case 4:
                    cout << "       * * *        ";
                    break;
            }
        }
        void printDiamonds(int line) {
            int L = line;
            switch(L) {
                case 0:
                    cout << "         *          ";
                    break;
                case 1:
                    cout << "       * * *        ";
                    break;
                case 2:
                    cout << "     * * * * *      ";
                    break;
                case 3:
                    cout << "       * * *        ";
                    break;
                case 4:
                    cout << "         *          ";
                    break;
            }
        }
        void printClubs(int line) {
            int L = line;
            switch(L) {
                case 0:
                    cout << "         *          ";
                    break;
                case 1:
                    cout << "       * * *        ";
                    break;
                case 2:
                    cout << "   * * * * * * *    ";
                    break;
                case 3:
                    cout << "   * * * * * * *    ";
                    break;
                case 4:
                    cout << "       * * *        ";
                    break;
            }
        }
        void nomove(int input) {
            int in = input;
            CardSource::nomove(in);
        }
        void resize() {
            CardSource::resize();
        }
};

int main() {   
    srand((unsigned int)time(NULL));
    ChineseTenTable sys;
    string key;
    int card, turn;
    cout << endl << "Welcome to my game of Chinese Ten!" << endl;
    cout << "Enter any key to Start New Game ";
    cin >> key;
    while(true) {
        sys.generate();
        cout << endl << "Deck shuffled successfully." << endl << endl;
        cout << "Your Cards: " << endl;
        sys.dealt();
        sys.print();
        turn = 1;
        cout << "Enter any key to start ";
        cin >> key;
        while(turn != -1) {
            if(sys.playerCard.size() >= 0 || sys.compCard.size() >= 0) {
                if(turn == 1) {
                    cout << endl << "Your turn" << endl;
                    sys.move();
                    if(sys.playerHand.size() != 0) {
                        cout << "Pick a move: (enter the number) " << endl;
                        cin >> card;
                        if(cin && card >= 0 && card < sys.playerHand.size()) {
                            sys.player(card);
                            sys.print();
                        }
                        else {
                            while(true) {
                                cout << "Input error! Please enter the correct input ";
                                cin >> card;
                                if(cin && card >= 0 && card < sys.playerHand.size())
                                    break;
                            }
                            sys.player(card);
                            sys.print();
                        }
                        cout << "Enter any key to end turn ";
                        cin >> key;
                        sys.resize();
                        sys.draw();
                        sys.print();
                        cout << "Enter any key to continue ";
                        cin >> key;
                    }
                    else {
                        cout << "You have no possible move to play" << endl;
                        for(int i=0; i<sys.playerCard.size(); i++)
                            cout << i << ". " << sys.playerCard.at(i) << "  ";
                        cout << endl << endl;
                        cout << "Pick a card to be placed in the table: (enter the number) " << endl;
                        cin >> card;
                        if(cin && card >= 0 && card < sys.playerCard.size()) {
                            sys.nomove(card);
                            sys.print();
                        }
                        else {
                            while(true) {
                                cout << "Input error! Please enter the correct input ";
                                cin >> card;
                                if(cin && card >= 0 && card < sys.playerCard.size())
                                    break;
                            }
                            sys.nomove(card);
                            sys.print();
                        }
                        cout << "Enter any key to end turn ";
                        cin >> key;
                    }
                }
                cout << endl << "Computer's turn" << endl;
                sys.computer();
                sys.print();
                cout << "Computer ended turn. Enter any key ";
                cin >> key;
                sys.resize();
                sys.draw();
                sys.print();
                cout << "Enter any key to continue ";
                cin >> key;
                turn = 1;
            }
            if(sys.playerCard.size() == 0 && sys.compCard.size() == 0) {
                cout << "-------------------------------------------------------------" << endl;
                cout << "Game over!" << endl << "Here are the results:" << endl << endl;
                sys.game();
                cout << "Play again?" << endl;
                cout << "Enter 1 to play again, any key to exit ";
                cin >> key;
                if(key == "1") {
                    turn = -1;
                }
                else
                    return 0;
            }
        }
    }
    return 0;
}