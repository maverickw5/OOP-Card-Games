#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
#include <fstream>
#define DECK 52
using namespace std;

class CardSource {
    int nSuit = 4;
    int nNum = 13;
    string cardSuit[4] = {"H", "S", "D", "C"};
    string cardNum[13] = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K"};
public:
    int nCard;
    string card;
    vector<string> Deck;
    string collect[DECK] = {};
    vector<string> playerCard;
    vector<string> compCard;
    string playerN[DECK/2] = {};
    string playerS[DECK/2] = {};
    string compN[DECK/2] = {};
    string compS[DECK/2] = {};
    string playerHand[7] = {};
    string compHand[7] = {};
    string playerFold[DECK/2] = {};
    string compFold[DECK/2] = {};
    string tmpN[12] = {};
    int playerCounter, compCounter, phandCount, chandCount, pfoldCount, cfoldCount;
    int hUp, sUp, dUp, cUp, hDown, sDown, dDown, cDown;
    void generate() {
        nCard = 0;
        for(int i=0; i<nSuit; i++) {
            for(int j=0; j<nNum; j++) {
                card = cardNum[j] + cardSuit[i];
                Deck.push_back(card);
                nCard++;
            }
        }
        while(nCard > 0) {
            int randCard = rand() % nCard;
            string drawCard = Deck.at(randCard);
            Deck.erase(Deck.begin() + randCard);
            nCard--;
            collect[nCard] = drawCard;
        }
    }
    void dealt() {
        int i = 0;
        while(i < DECK) {
            playerCard.push_back(collect[i]);
            i++;
            compCard.push_back(collect[i]);
            i++;
        }
        for(int i=0; i<DECK/2; i++) {
            string tmp1 = playerCard[i];
            playerN[i] = tmp1[0];
            playerS[i] = tmp1[1];
            string tmp2 = compCard[i];
            compN[i] = tmp2[0];
            compS[i] = tmp2[1];
        }
        for(int i=0; i<12; i++) {
            tmpN[i] = " ";
        }
        for(int i=0; i<DECK/2; i++) {
            compFold[i] = "";
        }
        playerCounter = compCounter = DECK/2;
        pfoldCount = cfoldCount = 0;
        hUp = sUp = dUp = cUp = 7;
        hDown = sDown = dDown = cDown = 5;
    }
    void showcard() {
        for(int i=0; i<DECK/2; i++) {
            cout << playerCard[i] << "  ";
            if(i == 12)
                cout << endl;
        }
        cout << endl << "Note: H = Hearts, S = Spades, D = Diamonds, C = Clubs, T = 10" << endl << endl;
    }
    void move() {
        if(phandCount == 0) {
            for(int i=0; i<playerCounter; i++) {
                cout << i << ". " << playerCard[i] << "  ";
                if(i == 12)
                    cout << endl;
            }
            cout << endl;
        }
        else {
            for(int i=0; i<phandCount; i++) {
                cout << i << ". " << playerHand[i] << "  ";
            }
            cout << endl;
        }
    }
    bool first() {
        int n;
        for(int i=0; i<DECK/2; i++) {
            if(playerCard[i] == "7S") {
                n = i;
                cout << endl << "You have Seven of Spades" << endl;
                tmpN[5] = playerN[n];
                playerCard.erase(playerCard.begin() + n);
                playerCounter--;
                return 1;
            }
            else if(compCard[i] == "7S") {
                n = i;
                cout << endl << "Computer has Seven of Spades" << endl;
                tmpN[5] = compN[n];
                compCard.erase(compCard.begin() + n);
                compCounter--;
                return 0;
            }
        }
    }
    void available() {
        int n;
        phandCount = 0;
        for(int i=0; i<7; i++) {
            playerHand[i] = "";
        }
        for(int i=0; i<playerCounter; i++) {
            string tmp = playerCard[i];
            playerN[i] = tmp[0];
            playerS[i] = tmp[1];
        }
        for(int i=0; i<playerCounter; i++) {
            if(playerN[i] == cardNum[6]) {
                n = i;
                playerHand[phandCount] = playerCard[n];
                phandCount++;
            }
        }
        for(int i=0; i<playerCounter; i++) {
            if(playerS[i] == "S") {
                if(playerN[i] == cardNum[sUp]) {
                    n = i;
                    playerHand[phandCount] = playerCard[n];
                    phandCount++;
                }
                else if(playerN[i] == cardNum[sDown]) {
                    n = i;
                    playerHand[phandCount] = playerCard[n];
                    phandCount++;
                }
            }
        }
        if(tmpN[4] != " ") {
            for(int i=0; i<playerCounter; i++) {
                if(playerS[i] == "H") {
                    if(playerN[i] == cardNum[hUp]) {
                        n = i;
                        playerHand[phandCount] = playerCard[n];
                        phandCount++;
                    }
                    else if(playerN[i] == cardNum[hDown]) {
                        n = i;
                        playerHand[phandCount] = playerCard[n];
                        phandCount++;
                    }
                }
            }
        }
        else if(tmpN[6] != " ") {
            for(int i=0; i<playerCounter; i++) {
                if(playerS[i] == "D") {
                    if(playerN[i] == cardNum[dUp]) {
                        n = i;
                        playerHand[phandCount] = playerCard[n];
                        phandCount++;
                    }
                    else if(playerN[i] == cardNum[dDown]) {
                        n = i;
                        playerHand[phandCount] = playerCard[n];
                        phandCount++;
                    }
                }
            }
        }
        else if(tmpN[7] != " ") {
            for(int i=0; i<playerCounter; i++) {
                if(playerS[i] == "C") {
                    if(playerN[i] == cardNum[cUp]) {
                        n = i;
                        playerHand[phandCount] = playerCard[n];
                        phandCount++;
                    }
                    else if(playerN[i] == cardNum[cDown]) {
                        n = i;
                        playerHand[phandCount] = playerCard[n];
                        phandCount++;
                    }
                }
            }
        }
    }
    void player(int input) {
        int n, in = input;
        string cardIn = playerHand[in];
        cout << "You played " << cardIn << endl;
        for(int i=0; i<playerCounter; i++) {
            if(playerCard[i] == cardIn) {
                n = i;
                if(playerS[n] == "S") {
                    if(playerN[n] == cardNum[sUp]) {
                        tmpN[1] = playerN[n];
                        playerCard.erase(playerCard.begin() + n);
                        playerCounter--;
                        sUp++;
                    }
                    else if(playerN[n] == cardNum[sDown]) {
                        tmpN[9] = playerN[n];
                        playerCard.erase(playerCard.begin() + n);
                        playerCounter--;
                        sDown--;
                    }
                }
                if(playerS[n] == "H") {
                    if(playerN[n] == "7") {
                        tmpN[4] = playerN[n];
                        playerCard.erase(playerCard.begin() + n);
                        playerCounter--;
                    }
                    else if(playerN[n] == cardNum[hUp]) {
                        tmpN[0] = playerN[n];
                        playerCard.erase(playerCard.begin() + n);
                        playerCounter--;
                        hUp++;
                    }
                    else if(playerN[n] == cardNum[hDown]) {
                        tmpN[8] = playerN[n];
                        playerCard.erase(playerCard.begin() + n);
                        playerCounter--;
                        hDown--;
                    }
                }
                if(playerS[n] == "D") {
                    if(playerN[n] == "7") {
                        tmpN[6] = playerN[n];
                        playerCard.erase(playerCard.begin() + n);
                        playerCounter--;
                    }
                    else if(playerN[n] == cardNum[dUp]) {
                        tmpN[2] = playerN[n];
                        playerCard.erase(playerCard.begin() + n);
                        playerCounter--;
                        dUp++;
                    }
                    else if(playerN[n] == cardNum[dDown]) {
                        tmpN[10] = playerN[n];
                        playerCard.erase(playerCard.begin() + n);
                        playerCounter--;
                        dDown--;
                    }
                }
                if(playerS[n] == "C") {
                    if(playerN[n] == "7") {
                        tmpN[7] = playerN[n];
                        playerCard.erase(playerCard.begin() + n);
                        playerCounter--;
                    }
                    else if(playerN[n] == cardNum[cUp]) {
                        tmpN[3] = playerN[n];
                        playerCard.erase(playerCard.begin() + n);
                        playerCounter--;
                        cUp++;
                    }
                    else if(playerN[n] == cardNum[cDown]) {
                        tmpN[11] = playerN[n];
                        playerCard.erase(playerCard.begin() + n);
                        playerCounter--;
                        cDown--;
                    }
                }
            }
        }
    }
    void fold(int input) {
        int in = input;
        playerFold[pfoldCount] = playerCard[in];
        cout << "You folded " << playerFold[pfoldCount] << endl << endl;
        playerCard.erase(playerCard.begin() + in);
        playerCounter--;
        pfoldCount++;
    }
    void computer() {
        int n;
        chandCount = 0;
        for(int i=0; i<7; i++) {
            compHand[i] = "";
        }
        for(int i=0; i<compCounter; i++) {
            string tmp = compCard[i];
            compN[i] = tmp[0];
            compS[i] = tmp[1];
        }
        for(int i=0; i<compCounter; i++) {
            if(compN[i] == cardNum[6]) {
                n = i;
                compHand[chandCount] = compCard[n];
                chandCount++;
            }
        }
        for(int i=0; i<compCounter; i++) {
            if(compS[i] == "S") {
                if(compN[i] == cardNum[sUp]) {
                    n = i;
                    compHand[chandCount] = compCard[n];
                    chandCount++;
                }
                else if(compN[i] == cardNum[sDown]) {
                    n = i;
                    compHand[chandCount] = compCard[n];
                    chandCount++;
                }
            }
        }
        if(tmpN[4] != " ") {
            for(int i=0; i<compCounter; i++) {
                if(compS[i] == "H") {
                    if(compN[i] == cardNum[hUp]) {
                        n = i;
                        compHand[chandCount] = compCard[n];
                        chandCount++;
                    }
                    else if(compN[i] == cardNum[hDown]) {
                        n = i;
                        compHand[chandCount] = compCard[n];
                        chandCount++;
                    }
                }
            }
        }
        else if(tmpN[6] != " ") {
            for(int i=0; i<compCounter; i++) {
                if(compS[i] == "D") {
                    if(compN[i] == cardNum[dUp]) {
                        n = i;
                        compHand[chandCount] = compCard[n];
                        chandCount++;
                    }
                    else if(compN[i] == cardNum[dDown]) {
                        n = i;
                        compHand[chandCount] = compCard[n];
                        chandCount++;
                    }
                }
            }
        }
        else if(tmpN[7] != " ") {
            for(int i=0; i<compCounter; i++) {
                if(compS[i] == "C") {
                    if(compN[i] == cardNum[cUp]) {
                        n = i;
                        compHand[chandCount] = compCard[n];
                        chandCount++;
                    }
                    else if(compN[i] == cardNum[cDown]) {
                        n = i;
                        compHand[chandCount] = compCard[n];
                        chandCount++;
                    }
                }
            }
        }
        string cardIn;
        if(chandCount == 0) {
            int n, low = 5;
            int random = rand() % compCounter;
            cout << "Computer has no card to play" << endl;
            for(int i=0; i<compCounter; i++) {
                n = i;
                if(compN[n] == cardNum[low]) {
                    compFold[cfoldCount] = compCard[n];
                    compCard.erase(compCard.begin() + n);
                    break;
                }
                low--;
            }
            if(compFold[cfoldCount] == "") {
                compFold[cfoldCount] = compCard[random];
                compCard.erase(compCard.begin() + random);
            }
            cout << "Computer folded " << compFold[cfoldCount] << endl << endl;
            compCounter--;
            cfoldCount++;
        }
        else if(chandCount == 1) {
            cardIn = compHand[0];
            cout << "Computer played " << cardIn << endl;
        }
        else {
            int random = rand() % chandCount;
            cardIn = compHand[random];
            cout << "Computer played " << cardIn << endl;
        }
        for(int i=0; i<compCounter; i++) {
            if(compCard[i] == cardIn) {
                n = i;
                if(compS[n] == "S") {
                    if(compN[n] == cardNum[sUp]) {
                        tmpN[1] = compN[n];
                        compCard.erase(compCard.begin() + n);
                        compCounter--;
                        sUp++;
                    }
                    else if(compN[n] == cardNum[sDown]) {
                        tmpN[9] = compN[n];
                        compCard.erase(compCard.begin() + n);
                        compCounter--;
                        sDown--;
                    }
                }
                if(compS[n] == "H") {
                    if(compN[n] == "7") {
                        tmpN[4] = compN[n];
                        compCard.erase(compCard.begin() + n);
                        compCounter--;
                    }
                    else if(compN[n] == cardNum[hUp]) {
                        tmpN[0] = compN[n];
                        compCard.erase(compCard.begin() + n);
                        compCounter--;
                        hUp++;
                    }
                    else if(compN[n] == cardNum[hDown]) {
                        tmpN[8] = compN[n];
                        compCard.erase(compCard.begin() + n);
                        compCounter--;
                        hDown--;
                    }
                }
                if(compS[n] == "D") {
                    if(compN[n] == "7") {
                        tmpN[6] = compN[n];
                        compCard.erase(compCard.begin() + n);
                        compCounter--;
                    }
                    else if(compN[n] == cardNum[dUp]) {
                        tmpN[2] = compN[n];
                        compCard.erase(compCard.begin() + n);
                        compCounter--;
                        dUp++;
                    }
                    else if(compN[n] == cardNum[dDown]) {
                        tmpN[10] = compN[n];
                        compCard.erase(compCard.begin() + n);
                        compCounter--;
                        dDown--;
                    }
                }
                if(compS[n] == "C") {
                    if(compN[n] == "7") {
                        tmpN[7] = compN[n];
                        compCard.erase(compCard.begin() + n);
                        compCounter--;
                    }
                    else if(compN[n] == cardNum[cUp]) {
                        tmpN[3] = compN[n];
                        compCard.erase(compCard.begin() + n);
                        compCounter--;
                        cUp++;
                    }
                    else if(compN[n] == cardNum[cDown]) {
                        tmpN[11] = compN[n];
                        compCard.erase(compCard.begin() + n);
                        compCounter--;
                        cDown--;
                    }
                }
            }
        }
    }
    void game() {
        int playerPoint = 0, compPoint = 0;
        string tmp, tmparr1[pfoldCount], tmparr2[cfoldCount];
        int n;
        for(int i=0; i<pfoldCount; i++) {
            tmp = playerFold[i];
            tmparr1[i] = tmp[0];
            n = i;
            for(int j=0; j<nNum; j++) {
                if(tmparr1[n] == cardNum[j])
                    playerPoint += j + 1;
            }
        }
        for(int i=0; i<cfoldCount; i++) {
            tmp = compFold[i];
            tmparr2[i] = tmp[0];
            n = i;
            for(int j=0; j<nNum; j++) {
                if(tmparr2[n] == cardNum[j])
                    compPoint += j + 1;
            }
        }
        if(playerPoint == compPoint)
            cout << "A tie!" << endl << endl;
        else if(playerPoint < compPoint)
            cout << "You win!" << endl << endl;
        else
            cout << "You lost!" << endl << endl;
        cout << "You folded " << pfoldCount << " card(s)" << endl;
        for(int i=0; i<pfoldCount; i++)
            cout << playerFold[i] << " ";
        cout << endl << "Your point is " << playerPoint << endl << endl;
        cout << "Computer folded " << cfoldCount << " card(s)" << endl;
        for(int i=0; i<cfoldCount; i++)
            cout << compFold[i] << " ";
        cout << endl << "Computer's point is " << compPoint << endl << endl;
    }
    ifstream rFile;
    ofstream wFile;
    void read() {
        string x;
        playerCounter = 0;
        compCounter = pfoldCount = cfoldCount = 0;
        rFile.open("gamesave.txt");
        if(!rFile) {
            cout << "Error! File not found." << endl;
            exit(1);
        }
        else {
            cout << "Reading file..." << endl;
            for(int i=0; i<12; i++) {
                getline(rFile, x);
                tmpN[i] = x;
            }
            rFile >> sUp >> hUp >> dUp >> cUp >> sDown >> hDown >> dDown >> cDown;
            getline(rFile, x);
            while(getline(rFile, x)) {
                if(x == ".")
                    break;
                playerCard.push_back(x);
                playerCounter++;
            }
            while(getline(rFile, x)) {
                if(x == ".")
                    break;
                compCard.push_back(x);
                compCounter++;
            }
            while(getline(rFile, x)) {
                if(x == ".")
                    break;
                playerFold[pfoldCount] = x;
                pfoldCount++;
            }
            while(getline(rFile, x)) {
                if(x == "!")
                    break;
                compFold[cfoldCount] = x;
                cfoldCount++;
            }
            rFile.close();
            if(playerCounter == 0 && compCounter == 0) {
                cout << "Error! No saved game." << endl;
                exit(1);
            }
        }
    }
    void save() {
        write();
        encrypt();
    }
    void write() {
        wFile.open("gamesave.txt", ofstream::trunc);
        wFile.close();
        wFile.open("gamesave.txt");
        if(!wFile) {
            cout << "Error! File not found." << endl;
            exit(1);
        }
        else {
            for(int i=0; i<12; i++) {
                wFile << tmpN[i] << endl;
            }
            wFile << sUp << endl << hUp << endl << dUp << endl << cUp << endl;
            wFile << sDown << endl << hDown << endl << dDown << endl << cDown << endl;
            for(int i=0; i<playerCounter; i++) {
                wFile << playerCard[i] << endl;;
            }
            wFile << "." << endl;
            for(int i=0; i<compCounter; i++) {
                wFile << compCard[i] << endl;
            }
            wFile << "." << endl;
            for(int i=0; i<pfoldCount; i++) {
                wFile << playerFold[i] << endl;
            }
            wFile << "." << endl;
            for(int i=0; i<cfoldCount; i++) {
                wFile << compFold[i] << endl;
            }
            if(crypt.size() > 0) {
                wFile << "!" << endl;
                for(int i=0; i<crypt.size(); i++)
                    wFile << crypt.at(i);
                cout << "Saving game..." << endl;
                cout << "Game saved successfully." << endl;
                cout << "File secured." << endl;
            }
            wFile.close();
        }
    }
    vector<string> crypt;
    int key[2] = {4, 7}, d = 0;
    void encrypt() {
        string tmp;
        rFile.open("gamesave.txt");
        while(getline(rFile, tmp)) {
            for(int i=0; i<tmp.size(); i++) {
                tmp[i] += key[d];
            }
            d = (d == 0) ? 1 : 0;
            crypt.push_back(tmp);
        }
        rFile.close();
        write();
    }
    void authenticate() {
        string decrypt, authentic, tmp;
        rFile.open("gamesave.txt");
        while(getline(rFile, tmp)) {
            if(tmp == "!")
                break;
            for(int i=0; i<tmp.size(); i++) { 
                tmp[i] += key[d];
            }
            d = (d == 0) ? 1 : 0;
            decrypt += tmp; 
        }
        getline(rFile, authentic);
        rFile.close();
        if(decrypt != authentic) {
            cout << "File has been altered!" << endl;
            cout << "Clearing file..." << endl;
            wFile.open("gamesave.txt", ofstream::trunc);
            wFile.close();
            cout << "[Disclaimer] Please don't modify the save file, otherwise it will be automatically cleared." << endl;
            exit(1);
        }
        cout << "File read successfully." << endl;
    }
};

class SevensTable: public CardSource {
    public:
        int counter;
        void print() {
            if(hUp > 7 || sUp > 7 || dUp > 7 || cUp > 7) {
                counter = 0;
                printCard();
                cout << endl;
            }
            counter = 4;
            printCard();
            cout << endl;
            if(hDown < 5 || sDown < 5 || dDown < 5 || cDown < 5) {
                counter = 8;
                printCard();
                cout << endl;
            }
        }
        void printCard() {
            printcardHeader();
            printcardNumber(0);
            counter -= 4;
            printcardSuit();
            printcardNumber(1);
            counter -= 4;
            printcardHeader();
            cout << endl;
        }
        void printcardHeader() {
            cout << endl;
            for(int x=0; x<4; x++) {
                for(int i=0; i<12; i++) {
                    cout << "[]";
                }
                cout << "   ";
            }
        }
        void printcardNumber(int topBottom) {
            int tb = topBottom;
            if(sUp == 13 && sDown == -1)
                tmpN[1] = tmpN[5] = tmpN[9] = " ";
            if(hUp == 13 && hDown == -1)
                tmpN[0] = tmpN[4] = tmpN[8] = " ";
            if(dUp == 13 && dDown == -1)
                tmpN[2] = tmpN[6] = tmpN[10] = " ";
            if(cUp == 13 && cDown == -1)
                tmpN[3] = tmpN[7] = tmpN[11] = " ";
            for(int y=0; y<3; y++) {
                cout << endl;
                for(int x=0; x<4; x++) {
                    for(int i=0; i<12; i++) {
                        if(i == 0 || i == 11)
                            cout << "[]";
                        else if(tb == 0 && y == 1 && i == 2) {
                            cout << tmpN[counter] << " ";
                            counter++;
                        }
                        else if(tb == 1 && y == 1 && i == 9) {
                            cout << " " << tmpN[counter];
                            counter++;
                        }
                        else
                            cout << "  ";
                    }
                    cout << "   ";
                }
            }
        }
        void printcardSuit() {
            for(int y=0; y<5; y++) {
                cout << endl;
                int l = y;
                for(int x=0; x<4; x++) {
                    int c = x;
                    cout << "[]";
                    if(hUp == 13 && hDown == -1)
                        printHearts(-1, c);
                    else
                        printHearts(l, c);
                    if(sUp == 13 && sDown == -1)
                        printSpades(-1, c);
                    else
                        printSpades(l, c);
                    if(dUp == 13 && dDown == -1)
                        printDiamonds(-1, c);
                    else
                        printDiamonds(l, c);
                    if(cUp == 13 && cDown == -1)
                        printClubs(-1, c);
                    else
                        printClubs(l, c);
                    cout << "[]   ";
                }
            }
        }
        void printHearts(int line, int column) {
            int L = line;
            int C = column;
            if(C == 0) {
                switch(L) {
                    case 0:
                        cout << "     * *   * *      ";
                        break;
                    case 1:
                        cout << "   * * * * * * *    ";
                        break;
                    case 2:
                        cout << "     * * * * *      ";
                        break;
                    case 3:
                        cout << "       * * *        ";
                        break;
                    case 4:
                        cout << "         *          ";
                        break;
                    default:
                        cout << "                    ";
                }
            }
        }
        void printSpades(int line, int column) {
            int L = line;
            int C = column;
            if(C == 1) {
                switch(L) {
                    case 0:
                        cout << "         *          ";
                        break;
                    case 1:
                        cout << "       * * *        ";
                        break;
                    case 2:
                        cout << "     * * * * *      ";
                        break;
                    case 3:
                        cout << "     * * * * *      ";
                        break;
                    case 4:
                        cout << "       * * *        ";
                        break;
                    default:
                        cout << "                    ";
                }
            }
        }
        void printDiamonds(int line, int column) {
            int L = line;
            int C = column;
            if(C == 2) {
                switch(L) {
                    case 0:
                        cout << "         *          ";
                        break;
                    case 1:
                        cout << "       * * *        ";
                        break;
                    case 2:
                        cout << "     * * * * *      ";
                        break;
                    case 3:
                        cout << "       * * *        ";
                        break;
                    case 4:
                        cout << "         *          ";
                        break;
                    default:
                        cout << "                    ";
                }
            }
        }
        void printClubs(int line, int column) {
            int L = line;
            int C = column;
            if(C == 3) {
                switch(L) {
                    case 0:
                        cout << "         *          ";
                        break;
                    case 1:
                        cout << "       * * *        ";
                        break;
                    case 2:
                        cout << "   * * * * * * *    ";
                        break;
                    case 3:
                        cout << "   * * * * * * *    ";
                        break;
                    case 4:
                        cout << "       * * *        ";
                        break;
                    default:
                        cout << "                    ";
                }
            }
        }
};

int main() {
    srand((unsigned int)time(NULL));
    SevensTable sys;
    string act;
    int card, turn = 0;
    while(true) {
        if(act != "-1") {
            cout << endl << "Welcome to my game of Sevens!" << endl;
            cout << "Enter 1 to Load Game Save, any key to Start New Game ";
            cin >> act;
        }
        if(act == "1") {
            sys.read();
            sys.authenticate();
            cout << "Enter any key to continue ";
            cin >> act;
            sys.print();
            turn = 1;
        }
        else {
            sys.generate();
            sys.dealt();
            cout << endl << "Deck shuffled and distributed successfully." << endl << endl;
            cout << "Your Cards: " << endl;
            sys.showcard();
            cout << "Enter any key to start ";
            cin >> act;
            sys.first();
            sys.print();
            if(!sys.first())
                turn = 1;
            else {
                turn = 0;
                cout << "Enter any key to continue ";
                cin >> act;
            }
        }
        while(turn != -1) {
            if(sys.phandCount >= 0 || sys.chandCount >= 0) {
                if(turn == 1) {
                    cout << "Your turn" << endl;
                    sys.available();
                    if(sys.phandCount != 0) {
                        cout << "Pick a card to play: (enter the number) " << endl;
                        sys.move();
                        cin >> card;
                        if(cin && card < sys.phandCount) {
                            sys.player(card);
                            sys.print();
                        }
                        else {
                            cout << "Input error!" << endl;
                            sys.save();
                            return 0;
                        }
                    }
                    else {
                        cout << "You have no card to play" << endl;
                        cout << "Pick a card to fold: (enter the number) " << endl;
                        sys.move();
                        cin >> card;
                        if(cin && card < sys.playerCounter)
                            sys.fold(card);
                        else {
                            cout << "Input error!" << endl;
                            sys.save();
                            return 0;
                        }
                    }
                    cout << "Enter 1 to end turn, any key to save game ";
                    cin >> act;
                    if(act != "1") {
                        cout << "Computer's turn" << endl;
                        sys.computer();
                        if(sys.chandCount != 0)
                            sys.print();
                        sys.save();
                        return 0;
                    }
                }
                cout << "Computer's turn" << endl;
                sys.computer();
                if(sys.chandCount != 0)
                    sys.print();
                turn = 1;
            }
            if(sys.phandCount == 0 && sys.chandCount == 0) {
                cout << "-------------------------------------------------------------" << endl;
                cout << "Game over!" << endl << "Here are the results:" << endl << endl;
                sys.game();
                cout << "Play again?" << endl;
                cout << "Enter 1 to play again, any key to exit ";
                cin >> act;
                if(act == "1") {
                    turn = -1;
                    act = "-1";
                }
                else
                    return 0;
            }
        }
    }
    return 0;
}